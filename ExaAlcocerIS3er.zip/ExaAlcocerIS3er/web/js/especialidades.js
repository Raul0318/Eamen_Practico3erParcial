var especialidades = {
                "TIC":[
                 "Venustiano Carranza",
                        "Xochimilco"
                    ],
                "AAL":[
                 "Venustiano Carranza",
                        "Xochimilco"
                    ],
                         }